public class KotyraList<T1, T2> {
    private T1[] elements1;
    private T2[] elements2;

    public KotyraList(T1[] elements1, T2[] elements2) {
        this.elements1 = elements1;
        this.elements2 = elements2;
    }
    public static <E> void printArray(E[] array1, E[] array2) {
        for (E element : array1) {
            System.out.print(element + " ");
        }
        System.out.println("\n");
        for (E element : array2) {
            System.out.print(element + " ");
        }
    }
}
