import java.util.function.Function;

public class Lambda {
    Function<Integer, String> funkcja = x -> String.format("Podano liczbe %d", x);
}
