import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.function.Function;

public class Main {
    public static void main(String[] args) throws IOException {
//        ------LISTA
//        String[] e1 = {"jeden", "dwa", "trzy", "cztery"};
//        Integer[] e2 = {1,2,3,4};
//        KotyraList<String, Integer> lista = new KotyraList<String, Integer>(e1, e2);
//        KotyraList.printArray(e1, e2);

//        ------LISTA
//        List<String> lista = new ArrayList<>();
//        lista.add("jeden");
//        lista.add("dwa");
//        System.out.println(lista.get(1));

//        ------HASHMAP
//        Map<Integer, String> mapa = new HashMap<>();
//        mapa.put(1, " Palec mitomana");
//        mapa.put(2, " Kolano kinomaniaka");
//        mapa.put(3, " cooo");
//        System.out.println(mapa);
//        System.out.println(mapa.remove(3));
//        System.out.println(mapa);

//        ------HASHSET
//        Set<String> set = new HashSet<>();
//        set.add("domek");
//        set.add("dom");
//        System.out.println(set);

//        ------String
//        String str1 = "przykladowy napis";
//        String str2 = new String("przykladowy napis");
//        System.out.println(str2);

//        ------StringBuilder
//        StringBuilder text = new StringBuilder();
//        for (int i = 0; i < 100; i++) {
//            text.append(" napis\n");
//        }
//        System.out.println(text);

//        ------Pliki
//        File file = new File("plik.txt");
//        try {
//            file.createNewFile();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//        ------FileWriter i FileReader
//        StringBuilder text1 = new StringBuilder();
//        for (int i = 0; i < 10; i++) {
//            text1.append("guwno ");
//        }
//        File file = new File("plik.txt");
//        try {
//            FileWriter fw = new FileWriter(file, true);
//            fw.write(String.valueOf(text1));
//            fw.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        String text = " ";
//        try {
//            FileReader fr = new FileReader(file);
//            int i;
//            while ((i = fr.read()) != -1) {
//                text  = text + (char)i;
//            }
//            fr.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        System.out.println(text);

//        ------BufferedWriter i BufferedReader
//        StringBuilder text = new StringBuilder();
//        for (int i = 0; i < 10; i++) {
//            text.append("guwno");
//        }
//        File file = new File("plik.txt");
//        BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
//        bw.write(String.valueOf(text));
//        bw.newLine();
//        bw.write(String.valueOf(text));
//        bw.close();
//
//        String text1 = " ";
//        BufferedReader br = new BufferedReader(new FileReader(file));
//        String line;
//        while ((line = br.readLine()) != null) {
//            text1 += line + "\n";
//        }
//        br.close();
//        System.out.println(text1);

//        ------BufferedReader ale z klasy Test
//        File file = new File("plik.txt");
//        String lines = Test.getAllLines(file);
//        System.out.println(lines);

//        ------Scanner
//        String text = " ";
//        File file = new File("plik.txt");
//        Scanner scanner = new Scanner(file);
//        while (scanner.hasNextLine()) {
//            text += scanner.nextLine();
//        }
//        scanner.close();
//        System.out.println(text);

//        ------Scanner, odczytywanie tylko numeru
//        File file = new File("plik.txt");
//        Scanner scanner = new Scanner(file);
//        int number = 0;
//        while (scanner.hasNext()) {
//            if (scanner.hasNextInt()) {
//                number = scanner.nextInt();
//                break;
//            }
//            scanner.next();
//        }
//        scanner.close();
//        System.out.println(number);

//        ------FileOutputStream, wczytywanie plikow binarnych
//        try {
//            FileOutputStream fout = new FileOutputStream("plik.bin", true);
//            byte[] data = {1, 2, 3, 4, 5};
//            fout.write(data);
//            fout.close();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }

//        ------FileInputStream, odczytywanie plikow binarnych
//        try {
//            FileInputStream fin = new FileInputStream("plik.bin");
//            int b;
//            while ((b = fin.read()) != -1) {
//                System.out.print((char) b);
//            }
//            fin.close();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }

//        ------DataOutputStream i DataInputStream, wczytywanie i odczytywanie typow prostych z plikow binarnych
//        FileOutputStream fout = new FileOutputStream("plik.bin");
//        DataOutputStream dout = new DataOutputStream(fout);
//        int[] array = {1,2,3,4,5};
//        for (int number : array) {
//            dout.writeInt(number);
//        }
//        dout.close();
//
//        FileInputStream fin = new FileInputStream("plik.bin");
//        DataInputStream din = new DataInputStream(fin);
//        List<Integer> list = new ArrayList<>();
//        while(din.available()>0) {
//            list.add(din.readInt());
//        }
//        din.close();
//        System.out.println(list);

//        ------Paths i Files
//        ---Odczytywanie danych z pliku
//        Path path = Paths.get("plik.txt");
//        List<String> lines = Files.readAllLines(path); // dzielenie na linie
//        System.out.println(lines);
//        String fileContent = Files.readString(path); // bez dzielenia na linie
//        System.out.println(fileContent);
//        ---Wczytywanie danych do pliku
//        Path path = Paths.get("plik.txt");
//        List<String> lines = new ArrayList<>();
//        lines.add("Linia 1");
//        lines.add("Linia 2");
//        lines.add("Linia 3");
//        Files.write(path, lines, StandardOpenOption.APPEND);

//        ------Random, generowanie losowego inta
//        Random generator = new Random();
//        System.out.println(generator.nextInt());

//        ------Lambda
        Function<Integer, String> funkcja = x -> String.format("Podano liczbe %d", x);
        System.out.println(funkcja.apply(2));
    }
}