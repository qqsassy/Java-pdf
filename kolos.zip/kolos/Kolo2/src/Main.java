public class Main {
    public static void main(String[] args) {
        Objekt obj = new Objekt(21,37);
        int num1 = obj.getNumber1();
        System.out.println(num1);
        int num2 = obj.getNumber2();
        System.out.println(num2);

        int num3 = NieObjekt.number1;
        System.out.println(num3);
        int num4 = NieObjekt.number2;
        System.out.println(num4);
    }
}