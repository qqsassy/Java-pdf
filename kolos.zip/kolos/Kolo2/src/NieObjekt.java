public class NieObjekt {
    public static int number1 = 15;
    public static int number2 = 10;


}
