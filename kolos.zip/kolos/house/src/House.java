//public class House {
//    public enum Color { BLUE, RED, GREEN, WHITE, BLACK };
//    private Color insideWallColor, outsideWallColor;
//    private double squareFootage;
//    private boolean onSale, hasGarage;
//    public House(Color insideWallColor, Color outsideWallColor, double squareFootage, boolean
//            hasGarage, boolean onSale) {
//        this.insideWallColor = insideWallColor;
//        this.outsideWallColor = outsideWallColor;
//        this.squareFootage = squareFootage;
//        this.onSale = onSale;
//        this.hasGarage = hasGarage;
//        if (hasGarage) {
//            this.squareFootage += 20;
//        }
//    }
//
//    public Color getInsideWallColor() {
//        return insideWallColor;
//    }
//
//    public Color getOutsideWallColor() {
//        return outsideWallColor;
//    }
//
//    public double getSquareFootage() {
//        return squareFootage;
//    }
//
//    public boolean isOnSale() {
//        return onSale;
//    }
//
//    public boolean isHasGarage() {
//        return hasGarage;
//    }
//}
public class House {
    public enum Color { BLUE, RED, GREEN, WHITE, BLACK };
    private Color insideWallColor, outsideWallColor;
    private Double squareFootage;
    private Boolean onSale, hasGarage;
    public static class Builder {
        private Double squareFootage = 0.0;
        private Color wallColor;
        private Boolean onSale = false, hasGarage = false;
        public Builder addSquareFootage(Double squareFootage) {
            this.squareFootage += squareFootage;
            return this;
        }
        public Builder wallColor(Color wallColor) {
            this.wallColor = wallColor;
            return this;
        }
        public Builder setOnSale() {
            this.onSale = true;
            return this;
        }
        public Builder addGarage() {
            this.hasGarage = true;
            this.squareFootage += 10;
            return this;
        }
        public House build() {
            House house = new House();
            house.insideWallColor = this.wallColor;
            house.outsideWallColor = this.wallColor;
            house.squareFootage = this.squareFootage;
            house.onSale = this.onSale;
            house.hasGarage = this.hasGarage;
            return house;
        }
    }
    private House() {}
}
