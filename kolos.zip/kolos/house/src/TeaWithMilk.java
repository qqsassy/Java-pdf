public class TeaWithMilk extends Tea {
    private static final int kcal = 30;
    private Tea baseTea;

    public TeaWithMilk(Tea baseTea) {
        this.baseTea = baseTea;
    }

    @Override
    public int getKcal() {
        return baseTea.getKcal() + kcal;
    }
}
