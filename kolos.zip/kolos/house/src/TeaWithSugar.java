public class TeaWithSugar extends Tea {
    private static final int kcal = 20;
    private Tea baseTea;

    public TeaWithSugar(Tea baseTea) {
        this.baseTea = baseTea;
    }

    @Override
    public int getKcal() {
        return baseTea.getKcal() + kcal;
    }
}
