public class Main {
    public static void main(String[] args) {
//        ------Zwyczajnie
//        House.Color colorOutside = House.Color.RED;
//        House.Color colorInside = House.Color.BLACK;
//        House house = new House(colorInside, colorOutside, 50, false, true);
//        String co = house.getOutsideWallColor().toString();
//        String ci = house.getInsideWallColor().toString();
//        Double sq = house.getSquareFootage();
//        Boolean hg = house.isHasGarage();
//        Boolean os = house.isOnSale();
//        System.out.println(co + " " + ci + " " + sq + " " + hg + " " + os);

//        ------BUILDER
//        House.Builder builder = new House.Builder();
//        builder.addSquareFootage(20.0);
//        builder.wallColor(House.Color.BLACK);
//        builder.addGarage();
//        builder.setOnSale();
//        House house = builder.build();

//        ------DEKORATOR
        Tea herbatka = new Tea();
        TeaWithSugar herbatkaZCukrem = new TeaWithSugar(herbatka);
        TeaWithMilk herbatkaZCukremIMlekiem = new TeaWithMilk(herbatkaZCukrem);
        int kcal = herbatkaZCukremIMlekiem.getKcal();
        System.out.println(kcal);
    }
}