public class Tea {
    private static final int kcal = 0;
    public int getKcal() {
        return kcal;
    }
}
