public class Main {
    Waiter.Money salary = new Waiter.Money(2137, "PLN");
    Waiter w = new Waiter("Jan", "Paweł", salary);
    S
}