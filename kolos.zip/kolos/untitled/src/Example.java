public class Example {
    public static final String VERSION = "1.0";

    private int a, b;

    public Example(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public Example(Example obj) {
        this.a = obj.a;
        this.b = obj.b;
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(int b) {
        this.b = b;
    }
}
