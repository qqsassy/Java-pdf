//public class Money {
//    public final double value;
//    public final String currencyType;
//
//    public Money(double value, String currencyType) {
//        if (value < 0) {
//            throw new IllegalArgumentException("Value cannot be negative");
//        }
//        this.value = value;
//        this.currencyType = currencyType;
//    }
//    public static Money toUSD(Money money) {
//        return new Money(money.value * 0.25, "USD");
//    }
//}
//public record Money(double value, String currencyType) {
//    public Money {
//        if (value <= 0) {
//            throw new IllegalArgumentException("Value cannot be negative");
//        }
//    }
//    public static Money toUSD(Money money) {
//        return new Money(money.value * 0.25, "USD");
//    }
//}
public class Money {
    private double value;
    private String currency;
    private double exchangeRate;
    public Money(double value, String currency) {
        this.value = value;
        this.currency = currency;
    }
    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
    public static Money toUSD(Money money) {
        return new Money(money.getValue() * 0.25, "USD");
    }

    public double toUSD1() {
        if (exchangeRate == 0.0) {
            exchangeRate = 0.25;
        }
        return exchangeRate * value;
    }
}
