//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        ------------------------------------------Zmienna staytyczna i finalna wyświetlająca zmienną bez tworzenia obiektu
//        String str = Example.VERSION;
//        System.out.println(str);

//        ------------------------------------------Kalkulator, a także przeładowanie
//        int addResult = Calculator.add(2100, 37);
//        System.out.println(addResult);
//        double addResult2 = Calculator.add(2100.1, 37.8);
//        System.out.println(addResult2);

//        ------------------------------------------Wykorzystywanie zmiennych prywatnych z innej klasy poprzez stworzenie obiektu, a także zastosowanie konstruktora kopiującego
//        Example obj = new Example(21, 37);
//        Example obj_copy = new Example(obj);
//        int num1 = obj_copy.getA();
//        int num2 = obj_copy.getB();
//        System.out.println(num1);
//        System.out.println(num2);

//        ------------------------------------------Wykorzystanie value object
//        Money pln = new Money(2.50, "PLN");
//        System.out.println(pln.value);
//        System.out.println(pln.currencyType);
//        Money usd = Money.toUSD(pln);
//        System.out.println(usd.value);
//        System.out.println(usd.currencyType);

//        ------------------------------------------To samo co value object, ale prościej za pomocą rekordu
//        Money pln = new Money(2.50, "PLN");
//        Money usd = Money.toUSD(pln);
//        System.out.println(pln);
//        System.out.println(usd);

        Money pln = new Money(2.50, "PLN");
        double valuePLN = pln.getValue();
        String currencyPLN = pln.getCurrency();
        System.out.println("Value: " + valuePLN + " | Currency: " + currencyPLN);
        Money usd = Money.toUSD(pln);
        double valueUSD = usd.getValue();
        String currencyUSD = usd.getCurrency();
        System.out.println("Value: " + valueUSD + " | Currency: " + currencyUSD);
        double usd2 = pln.toUSD1();
        double usdC = pln.toUSD1();
        System.out.println("Value: " + usdC + " | Currency: " + currencyUSD);


    }
}