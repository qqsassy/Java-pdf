public class Car {
    private String model;

    public Car(String model) {
        this.model = model;
    }
    public class Engine {
        public String engineType;

        public void setEngineType() {
            if (model.equals("BMW")) {
                engineType = "N74";
            }
        }
    }
}
