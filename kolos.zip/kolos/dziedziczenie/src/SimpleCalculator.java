public class SimpleCalculator implements Calculator {
    private Double memory;

    @Override
    public void clearMemory() {
        memory = null;
    }

    @Override
    public void saveMemory(double memory) {
        this.memory = memory;
    }

    double add(double a, double b) {
        return a + b;
    }
}
