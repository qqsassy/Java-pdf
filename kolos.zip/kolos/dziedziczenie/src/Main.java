import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("Jan", "Paweł");
        String fullName = emp.getFullName();
        System.out.println(fullName);
        Client cus = new Client("Kamil", "Marah");
        String fullname1 = cus.getFullName();
        System.out.println(fullname1);

//        -------------------------------------------

        Car bmw = new Car("BMW");
        Car.Engine engine = bmw.new Engine();
        engine.setEngineType();
        String enginee = engine.engineType;
        System.out.println(enginee);

        Waiter.Money salary = new Waiter.Money(2137, "PLN");
        Waiter w = new Waiter("Jan", "Paweł", salary);
        System.out.println(w.getSalary());
    }



}