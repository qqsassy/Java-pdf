public class Client extends Person {
    private int[] orders;

    public Client(String firstName, String lastName) {
        super(firstName, lastName);
        this.orders = orders;
    }

    public int[] getOrders() {
        return orders;
    }

    @Override
    public String getFullName() {
        return "Klient: " + super.getFullName();
    }
}