public class LEGO {
    private String set;

    public LEGO(String set) {
        this.set = set;
    }

    public class BEST {
        private String name;
        public void setName() {
            if (set.equals("BEST")) {
                name = "Star Wars";
            }
        }
    }
}
