public class Waiter {
    public static class Money {
        private double value;
        private String type;

        public Money(double value, String type) {
            this.value = value;
            this.type = type;
        }
    }
    private String firstName, lastName;
    private Money salary;

    public Waiter(String firstName, String lastName, Money salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
    }

    public String getSalary() {
        return salary.value + " " + salary.type;
    }
}
