public interface Calculator {
    public static final double PI = 3.14;
    public static final double E = 2.71;
    public abstract void clearMemory();
    public abstract void saveMemory(double memory);
}
