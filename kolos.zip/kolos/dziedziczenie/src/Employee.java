public class Employee extends Person {
    private double salary;
    private String companyName;

    public Employee(String firstName, String lastName) {
        super(firstName, lastName);
        this.salary = salary;
        this.companyName = companyName;
    }

    public double getSalary() {
        return salary;
    }

    public String getCompanyName() {
        return companyName;
    }

    @Override
    public String getFullName() {
        return "Pracownik: " + super.getFullName();
    }
}